<header>
    Projet Blog PHP
</header>