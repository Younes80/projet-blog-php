<!DOCTYPE html>
<html lang="en">

<head>
    <?php require_once './includes/head.php' ?>
</head>

<body>
    <?php require_once './includes/header.php' ?>
    <div class="container">
        <div class="content">
            Content
        </div>
    </div>
</body>

</html>